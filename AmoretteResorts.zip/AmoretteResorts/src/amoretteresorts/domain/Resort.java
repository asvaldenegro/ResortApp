/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amoretteresorts.domain;

import java.io.Serializable;

/**
 *
 * @author Amorette
 */
public class Resort implements Serializable{
    private String resortName = "";
    private String resortLocation = "";
    private String resortRating = "";

    public boolean validate(){
        if (resortName==null || resortName.equals("")) return false;
        if (resortLocation==null || resortLocation.equals("")) return false;
        if (resortRating==null || resortRating.equals("")) return false;
        return true;
    }
    
    @Override
    public boolean equals(Object obj){
        if(this==obj)return true;
        if(!(obj instanceof Resort))return true;
        Resort resort = (Resort)obj;
        if(!resort.equals(resort.resortName))return false;
        if(!resortLocation.equals(resort.resortLocation))return false;
        if(!resortRating.equals(resort.resortRating))return false;
        return true;
    }
    
    /**
     * @return the resortName
     */
    public String getResortName() {
        return resortName;
    }

    /**
     * @param resortName the resortName to set
     */
    public void setResortName(String resortName) {
        this.resortName = resortName;
    }

    /**
     * @return the resortLocation
     */
    public String getResortLocation() {
        return resortLocation;
    }

    /**
     * @param resortLocation the resortLocation to set
     */
    public void setResortLocation(String resortLocation) {
        this.resortLocation = resortLocation;
    }

    /**
     * @return the resortRating
     */
    public String getResortRating() {
        return resortRating;
    }

    /**
     * @param resortRating the resortRating to set
     */
    public void setResortRating(String resortRating) {
        this.resortRating = resortRating;
    }
}
