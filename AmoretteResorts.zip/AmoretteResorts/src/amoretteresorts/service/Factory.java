/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amoretteresorts.service;
import java.io.FileInputStream;
import java.util.*;
/**
 *
 * @author Amorette
 */
public class Factory {
    
    public IResortSvc getResortSvc(){
        return new ResortSvcSIOImpl();
    }
    
    private String getImplName(String serviceName) throws Exception{
        Properties props = new Properties();
        FileInputStream fis = new FileInputStream("Factory.properties");
        props.load(fis);
        fis.close();
        return props.getProperty(serviceName);
    }
    
    public IService getService(String serviceName) throws Exception{
        String implName = getImplName(serviceName);
        Class c = Class.forName(implName);
        return (IService) c.newInstance();
    }
}
