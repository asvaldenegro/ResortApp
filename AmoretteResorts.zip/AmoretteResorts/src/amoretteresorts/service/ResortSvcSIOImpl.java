/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amoretteresorts.service;
import amoretteresorts.domain.*;
import java.io.*;
import java.util.*;
/**
 *
 * @author Amorette
 */
public class ResortSvcSIOImpl implements IResortSvc{

    private static final String FILENAME = "resorts.sio";
    
    private List<Resort> resorts = new ArrayList<Resort>();
    
    private void writeFile(){
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILENAME));
            oos.writeObject(resorts);
            oos.close();
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public Resort store(Resort resort) throws SvcException {
        try {
            resorts.add(resort);
            writeFile();
        } catch (Exception e) {
            throw new SvcException(e.getMessage());
        }
        return resort;
    }
    
    public void clear(){
        resorts.clear();
        writeFile();
    }
}
