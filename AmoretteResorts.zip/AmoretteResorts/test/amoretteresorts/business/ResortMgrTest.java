/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amoretteresorts.business;

import amoretteresorts.domain.*;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Amorette
 */
public class ResortMgrTest {

    @Test
    public void testStore() throws Exception{
        Resort resort = new Resort();
        resort.setResortName("Sweet Palms");
        resort.setResortLocation("Santa Fe");
        resort.setResortRating("Fair");
        ResortMgr mgr = new ResortMgr();
        resort = mgr.create(resort);
        assertNotNull(resort);
    }
    
}
