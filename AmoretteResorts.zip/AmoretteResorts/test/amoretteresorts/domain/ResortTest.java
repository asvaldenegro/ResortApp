/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amoretteresorts.domain;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Amorette
 */
public class ResortTest {

    @Test
    public void testValidate() {
        Resort resort = new Resort();
        boolean result = resort.validate();
        
        assertFalse(result);
        resort.setResortName("Sick Resort");
        result = resort.validate();
        
        assertFalse(result);
        resort.setResortLocation("Los Angeles");
        result = resort.validate();
        
        assertFalse(result);
        resort.setResortRating("Decent");
        result = resort.validate();
        
        assertTrue(result);

    }
    @Test
    public void testEquals(){
        Resort resort1 = new Resort();
        resort1.setResortName("Sweet Palms");
        resort1.setResortLocation("Santa Fe");
        resort1.setResortRating("Fair");
        
        Resort resort2 = new Resort();
        boolean result = resort1.equals(resort2);
        assertFalse(result);
        
        resort2.setResortName("Sweet Palms");
        result = resort1.equals(resort2);
        assertFalse(result);
        
        resort2.setResortLocation("Santa Fe");
        result = resort1.equals(resort2);
        assertFalse(result);
        
        resort2.setResortRating("Fair");
        result = resort1.equals(resort2);
        
        assertTrue(result);
    }   
    
}
