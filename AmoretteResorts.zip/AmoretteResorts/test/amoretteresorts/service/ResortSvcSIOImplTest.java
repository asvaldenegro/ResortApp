/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amoretteresorts.service;

import org.junit.Test;
import static org.junit.Assert.*;
import amoretteresorts.domain.Resort;
/**
 *
 * @author Amorette
 */
public class ResortSvcSIOImplTest {

    @Test
    public void testStore() throws Exception{
        Resort resort = new Resort();
        resort.setResortName("Sweet Palms");
        resort.setResortLocation("Santa Fe");
        resort.setResortRating("Fair");
        IResortSvc svc = new ResortSvcSIOImpl();
        svc.clear();
        resort = svc.store(resort);
        assertNotNull(resort);
        }
    
}
